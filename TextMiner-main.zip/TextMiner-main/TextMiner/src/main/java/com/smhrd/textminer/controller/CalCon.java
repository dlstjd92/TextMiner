package com.smhrd.textminer.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class CalCon {

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/CalCon") public List<Map<String, Object>> calander() {
	 * 
	 * 
	 * 
	 * 
	 * System.out.println("연결됨");
	 * 
	 * 
	 * 
	 * }
	 */
	
	
}
