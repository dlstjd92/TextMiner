package com.smhrd.textminer.dto;

public interface LoginService {
	
	public LoginDTO memberLogin(LoginDTO loginDTO) throws Exception;
	
}
