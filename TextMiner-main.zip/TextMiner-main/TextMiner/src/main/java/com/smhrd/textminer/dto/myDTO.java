package com.smhrd.textminer.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class myDTO {

	
	
    
    private int totalCount;
    private int page;
    private int totalpage;
    private int limit;
    private int offset;
    
	
	
}
