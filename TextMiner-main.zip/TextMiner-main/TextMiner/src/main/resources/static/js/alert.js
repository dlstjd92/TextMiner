//const link = document.getElementById('myLink');
//link.addEventListener('click', function(event) {
//  event.preventDefault();
//  alert('로그인 후 이용해 주세요');
//});




