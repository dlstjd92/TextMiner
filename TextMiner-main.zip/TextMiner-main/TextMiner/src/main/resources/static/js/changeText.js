function changeText() {
    // 1 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head1").innerHTML = "새로운 제목1";
    document.getElementById("date1").innerHTML = "새로운 내용1";
    document.getElementById("contents1-1").innerHTML = "새로운 내용1";
    document.getElementById("contents1-2").innerHTML = "새로운 내용1";
    document.getElementById("contents1-3").innerHTML = "새로운 내용1";
    // 2 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head2").innerHTML = "새로운 제목2";
    document.getElementById("date2").innerHTML = "새로운 내용2";
    document.getElementById("contents2-1").innerHTML = "새로운 내용2";
    document.getElementById("contents2-2").innerHTML = "새로운 내용2";
    document.getElementById("contents2-3").innerHTML = "새로운 내용2";
    // 3 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head3").innerHTML = "새로운 제목3";
    document.getElementById("date3").innerHTML = "새로운 내용3";
    document.getElementById("contents3-1").innerHTML = "새로운 내용3";
    document.getElementById("contents3-2").innerHTML = "새로운 내용3";
    document.getElementById("contents3-3").innerHTML = "새로운 내용3";
    // 4 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head4").innerHTML = "새로운 제목4";
    document.getElementById("date4").innerHTML = "새로운 내용4";
    document.getElementById("contents4-1").innerHTML = "새로운 내용4";
    document.getElementById("contents4-2").innerHTML = "새로운 내용4";
    document.getElementById("contents4-3").innerHTML = "새로운 내용4";
    // 5 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head5").innerHTML = "새로운 제목4";
    document.getElementById("date5").innerHTML = "새로운 내용4";
    document.getElementById("contents5-1").innerHTML = "새로운 내용4";
    document.getElementById("contents5-2").innerHTML = "새로운 내용4";
    document.getElementById("contents5-3").innerHTML = "새로운 내용4";
    // 6 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head6").innerHTML = "새로운 제목6";
    document.getElementById("date6").innerHTML = "새로운 내용6";
    document.getElementById("contents6-1").innerHTML = "새로운 내용6";
    document.getElementById("contents6-2").innerHTML = "새로운 내용6";
    document.getElementById("contents6-3").innerHTML = "새로운 내용6";
    // 7 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head7").innerHTML = "새로운 제목7";
    document.getElementById("date7").innerHTML = "새로운 내용7";
    document.getElementById("contents7-1").innerHTML = "새로운 내용7";
    document.getElementById("contents7-2").innerHTML = "새로운 내용7";
    document.getElementById("contents7-3").innerHTML = "새로운 내용7";
    // 8 번째  h4 태그와 p 태그 내용 변경
    document.getElementById("head8").innerHTML = "새로운 제목8";
    document.getElementById("date8").innerHTML = "새로운 내용8";
    document.getElementById("contents8-1").innerHTML = "새로운 내용8";
    document.getElementById("contents8-2").innerHTML = "새로운 내용8";
    document.getElementById("contents8-3").innerHTML = "새로운 내용8";
    
    $("a.button btnFloat btnLightBlue").click(function(e){
    event.preventDefault();
   });
    
    
    
    
    
}