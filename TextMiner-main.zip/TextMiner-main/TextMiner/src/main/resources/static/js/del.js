$(document).ready(function() {
    $(".btn_delete").click(function() {
		
      	$(this).closest("tr").remove();
      
      
    });
  });
  

 
